package com.example.israel.myapplication;

public class Carrousel {
    String title;
    String message;
    String url_img;

    public Carrousel(String title,String mesagge, String url_img) {
        this.title = title;
        this.message = mesagge;
        this.url_img = url_img;
    }

    public String getTitle() {
        return title;
    }

    public String getMessage() {
        return message;
    }

    public String getUrlImg() {
        return url_img;
    }
}
