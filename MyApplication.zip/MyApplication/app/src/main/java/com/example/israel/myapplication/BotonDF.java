package com.example.israel.myapplication;

public class BotonDF {

    private String titulo;
    private String comando;

    public BotonDF(String titulo, String comando){
        this.titulo=titulo;
        this.comando= comando;
    }

    public String getTitulo(){
        return titulo;
    }

    public String getComando() {
        return comando;
    }
}
