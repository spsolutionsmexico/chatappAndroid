package com.example.israel.myapplication;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;

import java.util.List;

public class CarrouselAdapter extends ArrayAdapter<Carrousel> {
    private Activity activity;

    public CarrouselAdapter(Activity context, int resource, List<Carrousel> objets) {
        super(context, resource, objets);
        this.activity = context;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder holder;
        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

        int layoutResource = 0; // determined by view type
        Carrousel carrousel = getItem(position);
        int viewType = getItemViewType(position);

        if (carrousel.getTitle() != null) {
            layoutResource = R.layout.botones;
        }
        if (convertView != null) {
            holder = (CarrouselAdapter.ViewHolder) convertView.getTag();
        } else {
            convertView = inflater.inflate(layoutResource, parent, false);
            holder = new CarrouselAdapter.ViewHolder(convertView);
            convertView.setTag(holder);
        }


        return convertView;

    }

    private class ViewHolder {
        private LinearLayout card;

        public ViewHolder(View v) {
        }
    }
}
