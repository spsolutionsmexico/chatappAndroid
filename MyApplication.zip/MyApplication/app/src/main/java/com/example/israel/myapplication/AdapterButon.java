package com.example.israel.myapplication;

import android.app.Activity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import java.util.List;


public class AdapterButon extends ArrayAdapter<BotonDF> {

    private Activity activity;
    private List<BotonDF> messages;

    public AdapterButon (Activity context, int resource, List<BotonDF> objects) {
        super(context, resource, objects);
        this.activity = context;
        this.messages = objects;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        LayoutInflater inflater = (LayoutInflater) activity.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);

        int layoutResource = 0; // determined by view type
        BotonDF BotonDF = getItem(position);
        int viewType = getItemViewType(position);

        if (BotonDF.getTitulo() != null) {
            layoutResource = R.layout.botones;
        }
        if (convertView != null) {
            holder = (AdapterButon.ViewHolder) convertView.getTag();
        } else {
            convertView = inflater.inflate(layoutResource, parent, false);
            holder = new AdapterButon.ViewHolder(convertView);
            convertView.setTag(holder);
        }

        //set buton text
        holder.btn.setText(BotonDF.getTitulo());
        holder.btn.setTransitionName(BotonDF.getComando());
        holder.btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("v.getTransitionName ",v.getTransitionName());
                //MainActivity mainActivity = new MainActivity();
                //mainActivity.consultarws(v.getTransitionName());
            }
        });


        return convertView;
    }

    @Override
    public int getViewTypeCount() {
        // return the total number of view types. this value should never change
        // at runtime. Value 2 is returned because of left and right views.
        return 2;
    }

    @Override
    public int getItemViewType(int position) {
        // return a value between 0 and (getViewTypeCount - 1)
        return position % 2;
    }

    private class ViewHolder {
        private Button btn;
        public ViewHolder(View v) {
            btn = (Button) v.findViewById(R.id.button01);
        }
    }
}
